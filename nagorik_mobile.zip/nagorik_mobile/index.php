<?php
session_start();
include "library/dbconnect.php";
include 'library/library.php';
if ( !isset( $_SESSION ) || empty( $_SESSION ) ) {
  header( "Location: login.php" );
  exit();
} else {
 //print_r($_SESSION);
  ?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
<title>ভূমি মন্ত্রণালয় || কল</title>
<meta content="Admin Dashboard" name="description" />
<meta content="Themesbrand" name="author" />
<link rel="shortcut icon" href="../favicon.ico">
<link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="assets/css/metismenu.min.css" rel="stylesheet" type="text/css">
<link href="assets/css/icons.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="assets/plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css" rel="stylesheet">
<link href="assets//plugins/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css" rel="stylesheet">
<link href="assets/plugins/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
<link href="assets/plugins/bootstrap-touchspin/css/jquery.bootstrap-touchspin.min.css" rel="stylesheet" />
<!-- DataTables -->
<link href="assets/plugins/datatables/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
<link href="assets/plugins/datatables/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css" />
<!-- Responsive datatable examples -->

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<!-- Alertify CSS Start -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/alertify.min.css"/>
<link href="assets/css/style.css" rel="stylesheet" type="text/css">
    <style>
    #sso-widget .sso-icon img {
    width: 36px;
    height: 36px;
    border-radius: 50%;
    background: #ffffff;
    padding: 2px;
    margin-top: 14px;
}
        body{
            font-family: 'Hind Siliguri', sans-serif;
        }
    </style>
</head>

<body>

<!-- Begin page -->
<div id="wrapper"> 
  
  <!-- Top Bar Start -->
  <div class="topbar"> 
    
    <!-- LOGO -->
    <div class="topbar-left"> <a href="index.php" class="logo"> <span> <img style="height: 46px; margin:0px auto;" src="assets/images/gonoprojatontri.png" alt="" class="img-responsive"> 
      <!--<h3 style="color:white; font-size: 20px; padding-top: 16px;">Nextstore</h3>--> 
      </span> <i><img src="assets/images/gonoprojatontri.png" alt="" height="22"></i> </a> </div>
    
    <nav class="navbar-custom">
      
      <ul class="list-inline menu-left mb-0">
        <li class="float-left">
          <button class="button-menu-mobile open-left waves-effect"> <i class="mdi mdi-menu"></i> </button>
        </li>
      </ul>
    </nav>
  </div>
  <!-- Top Bar End --> 
  
  <!-- ========== Left Sidebar Start ========== -->
  <div class="left side-menu">
    <div class="slimscroll-menu" id="remove-scroll">
      <div id="sidebar-menu"> 
        <!-- Left Menu Start -->
        <ul class="metismenu">
          <li> <a href="index.php" class="waves-effect"> <i class="mdi mdi-view-dashboard"></i> <span> ড্যাসবোর্ড </span> </a> </li>
          
        </ul>
        <ul class="metismenu" id="side-menu">
             <li> <a href="complain.php" data-loc="pages/complain" class="waves-effect"> <i class="mdi mdi-calendar-check"></i> <span> অভিযোগ   </span> </a> </li>
            
            <li> <a href="info.php" data-loc="pages/info" class="waves-effect"> <i class="fa fa-info-circle" aria-hidden="true"></i> <span> কল অনুসন্ধান   </span> </a> </li>    
        </ul>
      </div>
      <!-- Sidebar -->
      <div class="clearfix"></div>
    </div>
    <!-- Sidebar -left --> 
    
  </div>
  <!-- Left Sidebar End --> 
  
  <!-- ============================================================== --> 
  <!-- Start right Content here --> 
  <!-- ============================================================== -->
  <div class="content-page"> 
    <!-- Start content -->
    <div class="content">
      <div class="container-fluid" >
        <div id="result">
          <div class="row">
            <div class="col-sm-12"> 
              <!--<div class="page-title-box">--> 
              <!--<h4 class="page-title" id="page_title">Dashboard</h4>--> 
              <!--<ol class="breadcrumb" id="breadcrumb_here">--> 
              <!--    <li class="breadcrumb-item active">--> 
              <!--        Welcome to Nextsotre Dashboard--> 
              <!--    </li>--> 
              <!--</ol>--> 
              <!--    <div class="state-information d-none d-sm-block">--> 
              <!--        <div class="state-graph">--> 
              <!--            <div id="header-chart-1"></div>--> 
              <!--            <div class="info">Balance $ 2,317</div>--> 
              <!--        </div>--> 
              <!--        <div class="state-graph">--> 
              <!--            <div id="header-chart-2"></div>--> 
              <!--            <div class="info">Item Sold 1230</div>--> 
              <!--        </div>--> 
              <!--    </div>--> 
              
              <!--</div>--> 
            </div>
          </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body text-center">
                            <h4><?= $_SESSION[ 'name' ]; ?>! জি আর এস এ আপনাকে স্বাগতম </h4>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
            <div class="col-xl-3 col-md-6">
              <div class="card mini-stat bg-primary">
                <div class="card-body mini-stat-img">
                  <div class="mini-stat-icon"> <i class="mdi mdi-cube-outline float-right"></i> </div>
                  <div class="text-white">
                    <h6 class="text-uppercase mb-3">মোট কল</h6>
                    <h4 class="mb-4"><?php pick("tbl_task","count(contact_number)","contact_number='".$_SESSION['mobile']."'");?></h4>
                    <span class="badge badge-info"> </span> <span class="ml-2">পূর্ববর্তী সময় থেকে</span> </div>
                </div>
              </div>
            </div>
            <div class="col-xl-3 col-md-6">
              <div class="card mini-stat bg-primary">
                <div class="card-body mini-stat-img">
                  <div class="mini-stat-icon"> <i class="mdi mdi-buffer float-right"></i> </div>
                  <div class="text-white">
                    <h6 class="text-uppercase mb-3">নতুন কল</h6>
                    <h4 class="mb-4"><?php pick("tbl_task","count(contact_number)","contact_number='".$_SESSION['mobile']."' and task_status=1");?></h4>
                    <span class="badge badge-danger"> </span> <span class="ml-2">পূর্ববর্তী সময় থেকে</span> </div>
                </div>
              </div>
            </div>
            <div class="col-xl-3 col-md-6">
              <div class="card mini-stat bg-primary">
                <div class="card-body mini-stat-img">
                  <div class="mini-stat-icon"> <i class="mdi mdi-tag-text-outline float-right"></i> </div>
                  <div class="text-white">
                    <h6 class="text-uppercase mb-3">চলমান কল</h6>
                    <h4 class="mb-4"><?php pick("tbl_task","count(contact_number)","contact_number='".$_SESSION['mobile']."' and task_status=2");?></h4>
                    <span class="badge badge-warning"> </span> <span class="ml-2">পূর্ববর্তী সময় থেকে</span> </div>
                </div>
              </div>
            </div>
            <div class="col-xl-3 col-md-6">
              <div class="card mini-stat bg-primary">
                <div class="card-body mini-stat-img">
                  <div class="mini-stat-icon"> <i class="mdi mdi-briefcase-check float-right"></i> </div>
                  <div class="text-white">
                    <h6 class="text-uppercase mb-3">নিষ্পন্ন কল</h6>
                    <h4 class="mb-4"><?php pick("tbl_task","count(contact_number)","contact_number='".$_SESSION['mobile']."' and task_status=3");?></h4>
                    <span class="badge badge-info"> </span> <span class="ml-2">পূর্ববর্তী সময় থেকে</span> </div>
                </div>
              </div>
            </div>
          </div> 
        </div>
      </div>
    </div>
    <!-- container-fluid --> 
    
  </div>
  <!-- content -->
  
  
</div>

<!-- ============================================================== --> 
<!-- End Right content here --> 
<!-- ============================================================== -->

</div>
<!-- END wrapper --> 

<!-- jQuery  --> 
<script src="assets/js/jquery.min.js"></script> 
<script src="assets/js/bootstrap.bundle.min.js"></script> 
<script src="assets/js/metisMenu.min.js"></script> 
<script src="assets/js/jquery.slimscroll.js"></script> 
<script src="assets/js/waves.min.js"></script> 
<script src="assets/plugins/jquery-sparkline/jquery.sparkline.min.js"></script> 

<!-- google maps api --> 
<script src="https://maps.google.com/maps/api/js?key=AIzaSyCtSAR45TFgZjOs4nBFFZnII-6mMHLfSYI"></script> 
<script src="https://cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script> 
<!-- Required datatable js --> 
<script src="assets/plugins/datatables/jquery.dataTables.js"></script> 
<script src="assets/plugins/datatables/datatables.min.js"></script> 
<script src="assets/plugins/datatables/dataTables.bootstrap4.min.js"></script> 
<script src="assets/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js"></script> 
<script src="assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js"></script> 
<script src="assets/plugins/bootstrap-touchspin/js/jquery.bootstrap-touchspin.min.js"></script> 

<!-- Responsive examples --> 

<script src="assets/plugins/select2/js/select2.min.js"></script> 
<script src="assets/plugins/parsleyjs/parsley.min.js"></script> 
<script src="assets/nestable/jquery.nestable.js"></script> 

<!-- Datatable init js --> 
<script src="assets/pages/datatables.init.js"></script> 
<script src="assets/pages/form-advanced.js"></script> 
<script src="assets/js/jquery.form.js"></script> 

<script src="assets/js/app.js"></script> 
<script src="assets/js/ajax.js"></script> 

</body>
</html>
<?php } ?>