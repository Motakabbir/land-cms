<?php
require_once 'config.php';
$data = $client->responseRequest($_POST);
echo 'Log in as : '.$data->name;
?>
