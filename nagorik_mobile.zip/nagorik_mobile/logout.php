<?php
require_once 'config.php';
session_start();
session_unset();
session_destroy();
setcookie( 'username', null, time() - 3600 );
setcookie( 'password', null, time() - 3600 );

$url='https://account.eksheba.gov.bd/';
$client->setRedirectUri( $app_redirect_url );
$authUrl = $client->logoutRequest();
header( "Location: " . $authUrl );
exit;
?>
