<?php
require_once 'config.php';
$client->setRedirectUri($app_redirect_url);
$authUrl = $client->loginRequest();
header("Location: ".$authUrl);
exit;
