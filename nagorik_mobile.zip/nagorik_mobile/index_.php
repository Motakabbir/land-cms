<?php 
require_once 'config.php';

$client->setRedirectUri('app_redirect_url');
$authUrl = $client->loginRequest();
print_r($authUrl);
//header("Location: ".$authUrl);

?>