
<form class="form-horizontal m-t-30" action="authenticate.php" method="post" name="login">
  <input type="text" name="nid" value="5076217693">
  <input type="text" name="dob" value="1990-09-30">
  <input type="text" name="Name" value="মোঃ মোতাকাব্বির মোরশেদ">
  <input type="text" name="mobile" value="01771882876">
  <button type="submit">Submit</button>
</form>
   