<?php
include( '../header.php' );
?>

<style>
label.col-sm-4.control-label {
    font-weight: bold;
}
span.color {
    color: red;
}
.form-group {
    margin-bottom: 5px;
}
</style>
<div id="mainContent">
  <div class="row">
    <div class="col-lg-12">
      <div class="card m-b-20">
        <div class="card-body">
<!--          <form id="aboutForm" class="" action="#" novalidate="" enctype="multipart/form-data">-->
          <div class="col-sm-12 ">
          <form class="form-horizontal" id="complaint_form" action="">
            <div class="row">
              <div class="col-md-6">
                <div class="form-group">
                  <input type="hidden" name="task_type" value="3">
                  <label for="txtcontact_person" class="col-sm-12 control-label">নাম <span class="color">*</span></label>
                  <div class="col-sm-12"> <span id="txtcontact_person-info" class="info" ></span>
                    <input type="text" class="form-control " name="txtcontact_person" id="txtcontact_person"  placeholder="নাম " value="<?php echo $_SESSION[ 'name' ];?>" readonly required>
                    <input type="hidden" name="txtclients_id" value="<?php echo $_SESSION[ 'id' ];?>">
                  </div>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label for="txtcontact_number" class="col-sm-12 control-label">মুঠোফোন<span class="color">*</span></label>
                  <div class="col-sm-12"> <span id="txtcontact_person_no-info" class="info" ></span>
                    <input type="text" class="form-control input-sm" name="txtcontact_number" id="txtcontact_number" value="<?php echo $_SESSION[ 'mobile' ];?>" placeholder="মুঠোফোন" <?php if($_SESSION[ 'mobile' ]!=''){ echo 'readonly';} ?> required>
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6 ">
                <div class="form-group">
                  <label for="txtcontact_number" class="col-sm-12 control-label">ইমেইল </label>
                  <div class="col-sm-12 ">
                    <input type="email" class="form-control input-sm" name="txtcontact_email" id="txtcontact_email" value="<?php echo  $_SESSION[ 'email' ];?>" placeholder="ইমেইল ">
                  </div>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label for="txtaddress" class="col-sm-12 control-label">ঠিকানা</label>
                  <div class="col-sm-12 "> <span id="txtaddress-info" class="info" ></span>
                    <textarea type="text" class="form-control " name='txtaddress' id='' placeholder="ঠিকানা" required><?php echo $_SESSION[ 'per_address' ];?></textarea>
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6">
                <div class="form-group">
                  <label for="service_type" class="col-sm-12 control-label">সেবার ধরন<span class="color">*</span></label>
                  <div class="col-sm-12"> <span id="service_type-info" class="info" ></span>
                    <select class="form-control input-sm select2 service_type" name='service_type' id='service_type' style="width:100%" required  data-parsley-min="1" data-parsley-required-message="You must select at least one option.">
                      <?php
                      createCombo( "সেবার ধরন", "tbl_service_type", "prob_id", "prob_name", "  where srv_type=1 Order by prob_id", '' );
                      ?>
                    </select>
                  </div>
                </div>
              </div>
              <div class="col-md-6 pro_others"  style="display:none">
                <div class="form-group">
                  <label for="others_problem" class="col-sm-12 control-label">অন্যান্য </label>
                  <div class="col-sm-12"> <span id="others_problem-info" class="info" ></span>
                    <input type="text" class="form-control input-sm" name="others_problem" id="others_problem" value="" placeholder="অন্যান্য">
                  </div>
                </div>
              </div>
              <div class="col-md-6 pro_diaplay" >
                <div class="form-group">
                  <label for="prob_id" class="col-sm-12 control-label">সমস্যার ধরন <span class="color">*</span></label>
                  <div class="col-sm-12"> <span id="prob_id-info" class="info" ></span>
                    <select class="form-control input-sm"  name='prob_id' id='prob_id'  required data-parsley-min="1" data-parsley-required-message="You must select at least one option.">
                      <?php
                      createCombo( "সমস্যার ধরন", "tbl_problem", "prob_id", "prob_name", "Order by prob_id", '' );
                      ?>
                    </select>
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6">
                <div class="form-group ">
                  <label for="division_id" class="col-sm-12 control-label">বিভাগের নাম <span class="color">*</span></label>
                  <div class="col-sm-12 " >
                    <select name="division_id" id="division_id" class="division_id form-control input-sm" required data-parsley-min="1" data-parsley-required-message="You must select at least one option.">
                      <?php
                      createCombo( "বিভাগ", "tbl_division", "id", "name", " ORDER BY name ", $_SESSION[ 'division_id' ] );
                      ?>
                    </select>
                  </div>
                </div>
              </div>
              <div class="col-md-6">
                <label for="name" class="col-sm-12 control-label">জেলার নাম <span class="color">*</span></label>
                <div class="col-sm-12"> <span id="name-info" class="info" ></span>
                  <select name="district" id="district" class="district form-control input-sm" required data-parsley-min="1" data-parsley-required-message="You must select at least one option.">
                    <?php
                    createCombo( "জেলা", "tbl_district", "id", "name", " ORDER BY name ", $_SESSION[ 'district_id' ] );
                    ?>
                  </select>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6 upodisplay"  >
                <div class="form-group ">
                  <label for="name" class="col-sm-4 control-label">উপজেলা/সার্কেলের নাম <span class="color">*</span></label>
                  <div class="col-sm-12"> <span id="name-info" class="info" ></span>
                    <select name="upozila" id="upozila" class="upozila form-control input-sm">
                      <?php
                      createCombo( "উপজেলা/সার্কেলের", "tbl_upozila", "id", "name", " ORDER BY name ", $_SESSION[ 'upozila_id' ] );
                      ?>
                    </select>
                  </div>
                </div>
              </div>
            </div>
            <div class="row"> </div>
            <div class="row">
              <input type="hidden" class="form-control datetimepicker time input-sm" name="down_time" id="down_time" value="<?php echo date('d/m/Y H:i');?>" placeholder="dd/mm/yy">
            </div>
            <div class="row">
              <div class=" col-md-8">
                <div class="form-group">
                  <label for="txtsubject" class="col-sm-4 control-label"> কলের বিষয় <span class="color">*</span></label>
                  <div class="col-sm-12"> <span id="txtsubject-info" class="info" ></span>
                    <input type="text" class="form-control input-sm" name="txtsubject" id="txtsubject" value="" placeholder="কলের বিষয়" required>
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class=" col-md-8">
                <div class="form-group">
                  <label for="txtdescription" class="col-sm-4 control-label"> কলের বিবরণ <span class="color">*</span></label>
                  <div class="col-sm-12"> <span id="txtdescription-info" class="info" ></span>
                    <textarea type="text" class="form-control " name='txtdescription' id='txtdescription' placeholder="কলের বিবরণ" required></textarea>
                  </div>
                </div>
              </div>
            </div>
            <div class="row montobo"   style="display:none">
              <div class=" col-md-8">
                <div class="form-group">
                  <label for="solv_solution" class="col-sm-3 control-label"> মন্তব্য <span class="color">*</span></label>
                  <div class="col-sm-12"> <span id="solv_solution-info" class="info" ></span>
                    <textarea type="text" class="form-control " name='solv_solution' id='solv_solution' placeholder="কলের বিবরণ"></textarea>
                  </div>
                </div>
              </div>
            </div>

        </div>
        <div class="form-group mt-2 mb-0 d-flex justify-content-end">
          <div>
            <button type="button" class="btn btn-secondary waves-effect" onclick="view_data()">Cancel</button>
            <button type="button" id="save" class="btn btn-primary waves-effect waves-light mr-1" onClick="save()"  >জমা দিন <i class="fa fa-floppy-o" aria-hidden="true"></i></button>
          </div>
        </div>
        </form>
      </div>
    </div>
  </div>
</div>
</div>
<?php include('../footer.php')?>
<script>
     var $loading = $('#loading').hide();
    $('#loading').hide();
$('.division_id').on('change',function(){
		var division_id = $(this).val();
		var mode = '1';
		//alert(txtclients_id);
		if(division_id >0){
		$.ajax({
			type: "POST",
			url: "../../../AjaxCode/loadajaxcombo.php?options=1&valueColumns=id,name",
			data: {
				mode: mode,
				division_id:division_id,							
				table:'tbl_district ',
				conditions:'where division_id=' +division_id,
				firstText:'জেলা নির্বাচন করুন',
			},
			success: function(response) {
				$('.district').html(response);
				$('.upozila').html('<option value="">প্রথমে জেলা নির্বাচন করুন</option>');
			}
		});
		}else{
			$('.district').html('<option value="">প্রথমে বিভাগ নির্বাচন করুন</option>');
			$('.upozila').html('<option value="">প্রথমে জেলা নির্বাচন করুন</option>');
			}
	});
$('.district').on('change',function(){
var district = $(this).val();
var mode = '1';
//alert(txtclients_id);
if(district >0){
$.ajax({
    type: "POST",
    url: "../../../AjaxCode/loadajaxcombo.php?options=1&valueColumns=id,name",
    data: {
        mode: mode,
        district:district,							
        table:'tbl_upozila ',
        conditions:'where district=' +district,
        firstText:'উপজেলার/সার্কেলের নাম নির্বাচন করুন',
    },
    success: function(response) {
        $('.upozila').html(response);
    }
});
}else{
    $('.upozila').html('<option value="">প্রথমে জেলা নির্বাচন করুন</option>');
    }
});

$('#txtcontact_number,#txtcontact_number_info').on('change',function(){
var txtcontact_number = $(this).val();
//alert(building);
if(txtcontact_number){
    $.ajax({
        type:'POST',
        url:'ajaxData.php',
        data:'txtcontact_number='+txtcontact_number,
        success:function(html){
            //alert(html)
            $('.history').html(html);
        }
    });
}
});


$('.service_type').on('change',function(){
var service_type = $(this).val();

//alert(service_type);
if(service_type==14){
    $('.pro_others').show();
}else{
    $('.pro_others').hide();
    }
/*if(service_type==8 || service_type==12 || service_type==11 || service_type==15 || service_type==16 || service_type==17){
        $('.montobo').show();
    }else{
        $('.montobo').hide();

        }*/

//alert(building);
if(service_type){
    $.ajax({
        type:'POST',
        url:'ajaxData.php',
        data:'service_type='+service_type,
        success:function(html){
            //console.log(html);
            var obj = JSON.parse(html);
            if(obj.show_problem==1){
                $('.pro_diaplay').show();
                }else{
                $('.pro_diaplay').hide();	
                    }
            if(obj.show_upozila==1){
                $('.upodisplay').show();
                }else{
                $('.upodisplay').hide();	
                    }


        }
    });
}


});
    
function save() {
    if($('form#complaint_form').parsley().validate()){
      var btn = document.getElementById('save');
        btn.disabled = true;
        btn.innerText = 'Posting...'
        $.ajax({
            type: "POST",
            url: "pages/complain/savecomplain.php",
            data: $('#complaint_form').serialize()
        }).done(function(response) {
            console.log(response);
            alertify.set('notifier','position', 'bottom-right');
            alertify.success(response);
            view_data();
        }).fail(function() {
            alertify.notify(response, 'error', 3)
        });
    }
}
</script> 
