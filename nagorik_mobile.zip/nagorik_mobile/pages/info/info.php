<?php include('../header.php')?>

<div id='mainContent'>
  <style>
.datepicker{
    border: 1px solid #ced4da !important;
}
    </style>
  <div class="row">
    <div class="col-12">
      <div class="card m-b-20">
        <div class="card-body" id="card-body">
          <h4 class="mt-0 header-title d-flex justify-content-between"> <span>কলের তালিকা</span> </h4>
          <form id="reportForm" class="form-group">
            <div class="row">
              <div class="col-lg-2">
                <input type="text" class="form-control datepicker" name="txtfromrec_date " id="txtfromrec_date" placeholder="From" />
              </div>
              <div class="col-lg-2">
                <input type="text" class="form-control datepicker" name="txttorec_date " id="txttorec_date" value="" placeholder="To" />
              </div>
              <div class="col-lg-2">
                <input class="form-control" name="task_no" id="task_no">
              </div>
              <div class="col-lg-2">
                <input value='Show Report' type='button' name='btnsubmit' class='forms_button_e btn btn-primary'  onclick='sendData()'>
              </div>
            </div>
          </form>
          <div id="loadContetn" class="mt-5" style="overflow-x:auto;"></div>
        </div>
      </div>
    </div>
  </div>
</div>
<script>
    function sendData(){
       
        $.ajax({
            type: "POST",
            url: "pages/info/info_get.php",
            data: $('#reportForm').serialize()
        }).done(function(msg) {
            console.log(msg);
            $("#loadContetn").html(msg);
        }).fail(function() {
            alert("error");
        });
    }
    sendData();
    /*function show_details(od_id){
        $.ajax({
            type: "POST",
            url: "pages/info/rpt_order_list_details.php",
            data: {
                od_id: od_id
            }
        }).done(function(msg) {
            console.log(msg)
            $("#mainContent").html(msg);
            $("#reportForm").hide();
        }).fail(function() {
            alert("error");
        });
    }*/
    $('.datepicker').datepicker({
    format: 'mm/dd/yyyy'
});
</script> 
