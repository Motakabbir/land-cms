<?php include('../header.php')?>
<div class="col-sm-12 ">
  <?php
  
  if ( isset( $_SESSION[ 'mobile' ] ) && !empty( $_SESSION[ 'mobile' ] ) ) {
    $mobile = $_SESSION[ 'mobile' ];
    $cond = 'where contact_number=' . $_SESSION[ 'mobile' ];
if ( isset( $_REQUEST[ 'task_no' ] ) && $_REQUEST[ 'task_no' ] != "" ) {
    if ( $cond != NULL ) {
      $cond .= " AND tbl_order.task_no='" . $_REQUEST[ 'task_no' ] . "'";
    } else {
      $cond = " WHERE tbl_order.task_no='" . $_REQUEST[ 'task_no' ] . "'";
    }
  }
  if ( isset( $_REQUEST[ 'txtfromrec_date' ] ) && $_REQUEST[ 'txtfromrec_date' ] != NULL ) {
    $pieces = explode( "/", $_REQUEST[ 'txtfromrec_date' ] );
    $txtfromrec_date = trim( $pieces[ 2 ] . "-" . $pieces[ 0 ] . "-" . $pieces[ 1 ], '-' );
    $pieces = explode( "/", $_REQUEST[ 'txttorec_date' ] );
    $txttorec_date = trim( $pieces[ 2 ] . "-" . $pieces[ 0 ] . "-" . $pieces[ 1 ], '-' );
    if ( $cond != NULL ) {
      $cond .= " AND (tbl_task.open_date>='$txtfromrec_date' AND tbl_task.open_date<='$txttorec_date')";
    } else {
      $cond = " WHERE (tbl_task.open_date>='$txtfromrec_date' AND tbl_task.open_date<='$txttorec_date')";
    }
  }
    $query = "SELECT
				 task_id,
				  task_no,
				  description,
				  contact_person_no,
				  contact_person,
				  solv_solution,
				  DATE_FORMAT(tbl_task.open_date, '%b %d %Y %h:%i %p') AS open_date,
				  task_status,
				  tbl_taskstatus.task_statusname,
				  _nisl_mas_member.User_Name,
				  (SELECT MAX(_nisl_mas_member.User_Name) FROM tbl_task_history LEFT JOIN _nisl_mas_member ON _nisl_mas_member.User_ID=tbl_task_history.update_by WHERE tbl_task.task_id=tbl_task_history.task_id and tbl_task_history.task_status=1) as sheby
				FROM tbl_task 
				LEFT JOIN tbl_taskstatus ON tbl_taskstatus.task_statusid = tbl_task.task_status
				LEFT JOIN _nisl_mas_member ON _nisl_mas_member.User_ID=tbl_task.scheduled_to
				" . $cond . " order by tbl_task.open_date desc";
    //echo $query;
    $ResultSet = mysql_query( $query )or die( "Invalid query: " . mysql_error() );
    ?>
  <div class="blog blog-info pl0 pr0">
    <div class="blog-body ">
      <table class="table table-bordered table-condensed table-striped table-hover" id="tableData">
        <thead>
          <tr>
            <th> কল নং</th>
            <th>কলের বিবরণ</th>
            <th>সমাধান</th>
            <th>যোগাযোগ নং</th>
            <th>তারিখ সময়</th>
            <th> অবস্থা</th>
            <th> যার দ্বারা সম্পন্ন হয়েছে</th>
            <th> যার দ্বারা সমর্থন হয়েছে</th>
          </tr>
        </thead>
        <?php

        while ( $qry_row = mysql_fetch_array( $ResultSet ) ) {
          extract( $qry_row );
          ?>
        <tr>
          <td><?php echo $task_no;?></td>
          <td><?php echo $description;?></td>
          <td><?php echo $solv_solution;?></td>
          <td><?php echo $contact_person_no;?></td>
          <td><?php echo $open_date;?></td>
          <td><?php echo $task_statusname;?></td>
          <td><?php echo $sheby;?></td>
          <td><?php echo $User_Name;?></td>
        </tr>
        <?php
        }
        ?>
      </table>
    </div>
  </div>
  <?php
  }
  ?>
</div>
