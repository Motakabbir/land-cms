<?php
include "../../../Library/dbconnect.php";
include "../../../Library/Library.php";
session_start();
if (!isset($_SESSION) || empty($_SESSION)){
    header("Location: login.php");
    exit();
}