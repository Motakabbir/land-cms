$(document).on('click', '#side-menu li a, .header-title a, .dropdown-menu a', function(e) {
 	e.preventDefault();
 	
	var page = $(this).attr('href');

	var loc = $(this).attr("data-loc");
	
	if($(this).attr('target') == '_blank')
		window.open(page,'_blank');

	if(page == 'javascript:void(0);')
		return false;

	window.location.hash = page;

 	$("#sidebar-menu li, #sidebar-menu li a").removeClass('active');
 	$("#sidebar-menu ul").removeClass('in');

 	$("#sidebar-menu a").each(function () {
        var pageUrl = window.location.hash.substr(1);
        
        if($(this).attr('href') == pageUrl) {
            $(this).addClass("active");
            $(this).parent().addClass("active"); // add active to li of the current link
            $(this).parent().parent().addClass("in");
            $(this).parent().parent().prev().addClass("active"); // add active class to an anchor
            $(this).parent().parent().parent().addClass("active");
            $(this).parent().parent().parent().parent().addClass("in"); // add active to li of the current link
            $(this).parent().parent().parent().parent().parent().addClass("active");
        }
    });

 	if(page == "javascript:void(0);")
		return false;

    var bread = "";
		
	$.ajax({
	    url: loc +'/'+page,
	    cache:false,
	    dataType: 'html',
	    type: "GET",
	    success: function(data) {
			$("#result").html(data);

			
			var now_page = page.split('.');
			if(now_page[0] == 'index')
			{
				$('#page_title').empty(); $('#page_title').append('dashboard');
				$('#breadcrumb_here').empty("");
				$('#breadcrumb_here').append("<li class='breadcrumb-item active'>Welcome to Lexa Dashboard</li>");
			}
			else
			{
				var temp = now_page[0].replace("_"," ");
				$('#page_title').empty(); $('#page_title').append(temp);
				$('#breadcrumb_here').empty();
				$('#breadcrumb_here').append("<li class='breadcrumb-item'><a>Home</a></li> <li class='breadcrumb-item'><a>"+temp+"</a></li>");
			}

	        window.location.hash = page;
            
	        $(window).scrollTop(0);
	    }
	});
});

$(document).ready(function(){
	var path = window.location.hash.substr(1);
	if(path)
		$('#sidebar-menu li:has(a[href="' + path + '"])').children('a').trigger('click');
	else
		$('#sidebar-menu li:has(a[href="index.html"])').children('a').trigger('click');
});