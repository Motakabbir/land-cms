<?php
	error_reporting(0);
        session_start();
//secho $_SESSION['SUserID']."mizan";
        if(!$_SESSION['SUserID'])
               die("Session Expaird");	
               		
?>
