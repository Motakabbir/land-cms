<?php
	//ini_set('display_errors', 'OFF');
	error_reporting(E_ALL);
	$servername = "localhost"; 
	$usernames = "root";
	$passwords = "";
	$dbname = "landnew";
	$conn = mysqli_connect($servername, $usernames, $passwords, $dbname) or die("Connection failed: " . mysqli_connect_error()); 
	mysqli_query($conn,"SET CHARACTER SET 'utf8'");
		mysqli_query($conn,"SET SESSION collation_connection ='utf8_unicode_ci'");
	if (mysqli_connect_errno()){
		echo "Failed to connect to MySQL: " . mysqli_connect_error();
	}
?>
